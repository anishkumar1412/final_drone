import { v2 as cloudinary } from 'cloudinary'
import Drone from '../models/drone.js';
import Booking from '../models/Booking.js';
import jwt from 'jsonwebtoken'
import mongoose from 'mongoose';
import Crop from '../models/cropModel.js';
import { Admin } from '../models/Admin.js';
import bcrypt from 'bcryptjs'
import WorkingDay from '../models/WorkingDay.js'

import db1 from '../models/index.js';
import { Sequelize } from 'sequelize';











const { Drone1, DroneArms, DroneBattery, DroneMotor, DronePropeller, sequelize } = db1;

// const createFullDrone = async (req, res) => {
//   const t = await sequelize.transaction();

//   try {
//     const data = req.body;

//     // 1. Create the main Drone
//     const newDrone = await Drone1.create({
//       owner_id: data.owner_id,
//       model: data.model,
//       name: data.name,
//       range: data.range,
//       speed: data.speed,
//       weight: data.weight,
//       is_level_sensor: data.is_level_sensor,
//       level_sensor_id: data.level_sensor_id,
//       is_allen_key: data.is_allen_key,
//       allen_key_id: data.allen_key_id,
//       water_pump_id: data.water_pump_id,
//       is_extension_board: data.is_extension_board,
//       extension_board_id: data.extension_board_id
//     }, { transaction: t });

//     const droneId = newDrone.id;

//     // 2. Insert into DroneArms
//     await DroneArms.create({
//       drone_id: droneId,
//       arms_id: data.arms_id,
//       arms_qty: data.arms_qty
//     }, { transaction: t });

//     // 3. Insert into DroneBattery
//     await DroneBattery.create({
//       drone_id: droneId,
//       battery_id: data.battery_id,
//       battery_qty: data.battery_qty
//     }, { transaction: t });

//     // 4. Insert into DroneMotor
//     await DroneMotor.create({
//       drone_id: droneId,
//       motor_id: data.motor_id,
//       motor_qty: data.motor_qty
//     }, { transaction: t });

//     // 5. Insert into DronePropeller
//     await DronePropeller.create({
//       drone_id: droneId,
//       propeller_id: data.propeller_id,
//       propeller_qty: data.propeller_qty
//     }, { transaction: t });

//     await t.commit();
//     res.status(201).json({ message: 'Drone and related parts created in separate tables successfully.' });

//   } catch (error) {
//     await t.rollback();
//     console.error(error);
//     res.status(500).json({ error: 'Failed to insert drone and related data.' });
//   }
// };


const createFullDrone = async (req, res) => {
  const t = await sequelize.transaction();

  try {
    const data = req.body;

    // 1. Create the main Drone
    const newDrone = await Drone1.create({
      owner_id: data.owner_id,
      model: data.model,
      name: data.name,
      range: data.range,
      speed: data.speed,
      weight: data.weight,
      is_level_sensor: data.is_level_sensor,
      level_sensor_id: data.level_sensor_id,
      is_allen_key: data.is_allen_key,
      allen_key_id: data.allen_key_id,
      water_pump_id: data.water_pump_id,
      is_extension_board: data.is_extension_board,
      extension_board_id: data.extension_board_id,
      createdAt:new Date()
    }, { transaction: t });

    const droneId = newDrone.id;

    // 2. Insert into DroneArms
    await DroneArms.create({
      drone_id: droneId,
      arms_id: data.arms_id,
      arms_qty: data.arms_qty
    }, { transaction: t });

    // 3. Insert into DroneBattery
    await DroneBattery.create({
      drone_id: droneId,
      battery_id: data.battery_id,
      battery_qty: data.battery_qty
    }, { transaction: t });

    // 4. Insert multiple motors into DroneMotor with motor_number added
    if (Array.isArray(data.motors)) {
      const motorEntries = data.motors.map((motor, index) => ({
        drone_id: droneId,
        motor_number: motor.motor_number ?? index + 1, // Use provided motor_number or fallback to index+1
        motor_id: motor.motor_id,
        motor_qty: motor.motor_qty,
        motor_type: motor.motor_type,
        motor_speed: motor.motor_speed,
        motor_power: motor.motor_power
      }));

      await DroneMotor.bulkCreate(motorEntries, { transaction: t });
    }

    // 5. Insert into DronePropeller
    await DronePropeller.create({
      drone_id: droneId,
      propeller_id: data.propeller_id,
      propeller_qty: data.propeller_qty
    }, { transaction: t });

    await t.commit();
    res.status(201).json({ message: 'Drone and related parts created successfully.' });

  } catch (error) {
    await t.rollback();
    console.error(error);
    res.status(500).json({ error: 'Failed to insert drone and related data.' });
  }
};



const getFullDroneById = async (req, res) => {
  const droneId = req.params.id;

  try {
    // 1. Get main drone info
    const drone = await Drone1.findOne({ where: { id: droneId } });

    if (!drone) {
      return res.status(404).json({ message: "Drone not found" });
    }

    // 2. Get arms
    const arms = await DroneArms.findAll({ where: { drone_id: droneId } });

    // 3. Get batteries
    const batteries = await DroneBattery.findAll({ where: { drone_id: droneId } });

    // 4. Get motors
    const motors = await DroneMotor.findAll({ where: { drone_id: droneId } });

    // 5. Get propellers
    const propellers = await DronePropeller.findAll({ where: { drone_id: droneId } });

    // Combine and send
    res.status(200).json({
      drone,
      arms,
      batteries,
      motors,
      propellers
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch drone data" });
  }
};

const getAllDronesWithParts = async (req, res) => {
  try {
    // 1. Fetch all drones
    const drones = await Drone1.findAll();

    // 2. Fetch all parts
    const allArms = await DroneArms.findAll();
    const allBatteries = await DroneBattery.findAll();
    const allMotors = await DroneMotor.findAll();
    const allPropellers = await DronePropeller.findAll();

    // 3. Merge parts into corresponding drones
    const fullDrones = drones.map(drone => {
      const droneId = drone.id;
      return {
        ...drone.toJSON(),
        arms: allArms.filter(arm => arm.drone_id === droneId),
        batteries: allBatteries.filter(bat => bat.drone_id === droneId),
        motors: allMotors.filter(motor => motor.drone_id === droneId),
        propellers: allPropellers.filter(prop => prop.drone_id === droneId)
      };
    });

    res.status(200).json(fullDrones);

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch drones and their parts." });
  }
};




// module.exports = {  };




const addDrone = async (req, res) => {
  try {
    const {
      model, range, speed, weight, price, district, state, owner, propeller, arms,
      motor, lGear, nozzle, nutBold, bableBare, lnkey, waterPump, pipeQty, charger,
      chargerCable, chargerPcable, extaintionBoard, battery, transmeterAndReciever
    } = req.body;

    const imageFile = req.file;

    console.log({
      model, range, speed, weight, price, district, state, owner, propeller, arms,
      motor, lGear, nozzle, nutBold, bableBare, lnkey, waterPump, pipeQty, charger,
      chargerCable, chargerPcable, extaintionBoard, battery, transmeterAndReciever
    }, imageFile);

    // Check for missing data
    if (!model || !range || !speed || !weight || !price || !district || !state || !owner ||
      !propeller || !arms || !motor || !lGear || !nozzle || !nutBold || !bableBare || !lnkey ||
      !waterPump || !pipeQty || !charger || !chargerCable || !chargerPcable ||
      !extaintionBoard || !battery || !transmeterAndReciever) {
      return res.json({ success: false, message: "Missing Details" });
    }

    // Upload image to Cloudinary
    const imageUpload = await cloudinary.uploader.upload(imageFile.path, { resource_type: "image" });
    const imageUrl = imageUpload.secure_url;

    const droneData = {
      model,
      range,
      speed,
      weight,
      price,
      district,
      state,
      owner,
      propeller,
      arms,
      motor,
      lGear,
      nozzle,
      nutBold,
      bableBare,
      lnkey,
      waterPump,
      pipeQty,
      charger,
      chargerCable,
      chargerPcable,
      extaintionBoard,
      battery,
      transmeterAndReciever,
      image: imageUrl,
    };

    const newDrone = new Drone(droneData);
    await newDrone.save();

    res.json({ success: true, message: "Drone Added Successfully" });
  } catch (error) {
    console.log(error);
    res.json({ success: false, message: error.message });
  }
};

const addCrop = async (req, res) => {
  try {
    const {cropName ,cropPerAcer } = req.body;

    const imageFile = req.file;

    console.log({
       cropName,cropPerAcer
    }, imageFile);

    // Check for missing data
    if (!cropName || !cropPerAcer) {
      return res.json({ success: false, message: "Missing Details" });
    }

    // Upload image to Cloudinary
    const imageUpload = await cloudinary.uploader.upload(imageFile.path, { resource_type: "image" });
    const imageUrl = imageUpload.secure_url;

    const cropData = {
      cropName,cropPerAcer,
      image: imageUrl,
    };

    const newCrop = new Crop(cropData);
    await newCrop.save();

    res.json({ success: true, message: "Crop Added Successfully" });
  } catch (error) {
    console.log(error);
    res.json({ success: false, message: error.message });
  }
};


const loginAdmin = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (email === process.env.ADMIN_EMAIL && password === process.env.ADMIN_PASSWORD) {
      const token = jwt.sign(email + password, process.env.JWT_SECRET)
      res.json({ success: true, token })
    } else {
      res.json({ success: false, message: "Invalid credentials" })
    }
  } catch (error) {
    console.log(error)
    res.json({ success: false, message: error.message })

  }
}

export const registerAdmins = async (req, res) => {
  try {
    const { name, email, password, role, access } = req.body;
    console.log(req.body);
    
    const existingAdmin = await Admin.findOne({ email });
    if (existingAdmin) return res.status(400).json({ message: "Admin already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);

    const newAdmin = new Admin({ name, email, password: hashedPassword, role, access });
    await newAdmin.save();

    res.status(201).json({ message: "Admin created successfully" });
  } catch (error) {
    console.log(error)
    res.status(500).json({ message: "Server Error", error });
  }
};

export const loginAdmins = async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log(req.body)
    

    const admin = await Admin.findOne({ email });
    if (!admin) return res.status(400).json({ message: "Admin not found" });

    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

    const token = jwt.sign(
      { id: admin._id, role: admin.role, access: admin.access },
      process.env[`${admin.role.toUpperCase()}_SECRET`],
      { expiresIn: "1h" }
    );
    console.log(token,admin)
    res.status(201).json({ success: true,token, admin });
    console.log("he")
  } catch (error) {
    res.status(500).json({ message: "Server Error", error });
  }
};

export const getAllAdmins = async (req, res) => {
  try {
    const admins = await Admin.find().select("-password");
    res.json(admins);
  } catch (error) {
    res.status(500).json({ message: "Server Error", error });
  }
};


const getAllBookings = async (req, res) => {
  try {
    const allBooking = await Booking.find({}); // Await the query result

    if (allBooking.length === 0) {  // Check if no bookings exist
      return res.json({ success: false, message: "No Booking Available" });
    }

    res.json({ success: true, allBooking }); // Send only plain objects
  } catch (error) {
    console.error("Error fetching bookings:", error);
    res.status(500).json({ success: false, message: "Server Error" });
  }
};


const adminCancelBooking = async (req, res) => {
  try {
    const droneId = req.params.id; // Extract droneId from the URL
    const { startDate, endDate } = req.body;

    // Check if droneId is valid
    if (!mongoose.Types.ObjectId.isValid(droneId)) {
      return res.status(400).json({ message: "Invalid drone ID" });
    }

    // Find the booking and mark it as cancelled
    const booking = await Booking.findOneAndUpdate(
      { droneId: new mongoose.Types.ObjectId(droneId), startDate, endDate },
      { $set: { cancelled: true } },
      { new: true }
    );

    if (!booking) {
      return res.status(404).json({ message: "Booking not found" });
    }

    // Find the drone and remove the booking
    const drone = await Drone.findById(droneId);
    if (!drone) {
      return res.status(404).json({ message: "Drone not found" });
    }

    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate);

    // Check if the booking exists in the drone's bookings array
    const bookingIndex = drone.bookings.findIndex(
      (booking) =>
        booking.startDate.toString() === startDateObj.toString() &&
        booking.endDate.toString() === endDateObj.toString()
    );

    if (bookingIndex === -1) {
      return res.status(404).json({ message: "Booking not found" });
    }

    // Remove the booking from the bookings array
    // Use $pull operator to remove the booking from the database
    await Drone.findByIdAndUpdate(
      droneId,
      { $pull: { bookings: { startDate: startDateObj, endDate: endDateObj } } },
      { new: true }
    );

    res.status(200).json({
      message: "Booking cancelled successfully",
      success: true,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Internal server error", error: error.message });
  }
};


const removeDrone = async (req, res) => {
  try {
    const { id } = req.params; // Get drone ID from URL params

    console.log("🔍 Removing Drone ID:", id);

    // Check if the drone exists
    const drone = await Drone.findById(id);
    if (!drone) {
      return res.status(404).json({ success: false, message: "Drone not found" });
    }

    // Delete the drone
    await Drone.findByIdAndDelete(id);

    res.json({ success: true, message: "Drone removed successfully" });
  } catch (error) {
    console.error(" Error removing drone:", error);
    res.status(500).json({ success: false, message: "Server Error" });
  }
};

const removeCrop = async (req, res) => {
  try {
    const { id } = req.params; // Get drone ID from URL params

    console.log("🔍 Removing Crop ID:", id);

    // Check if the drone exists
    const crop = await Crop.findById(id);
    if (!crop) {
      return res.status(404).json({ success: false, message: "Drone not found" });
    }

    // Delete the drone
    await Crop.findByIdAndDelete(id);

    res.json({ success: true, message: "Crop removed successfully" });
  } catch (error) {
    console.error(" Error removing drone:", error);
    res.status(500).json({ success: false, message: "Server Error" });
  }
};


const changeAvailability = async (req,res)=>{
  // Assuming you're using Express
  const { id } = req.params;
  const { availability } = req.body;
  console.log("It is working")

  try {
    const drone = await Drone.findById(id);
    if (!drone) {
      return res.status(404).json({ message: 'Drone not found' });
    }
   

    drone.availability = availability;
    await drone.save();

    res.json({ message: 'Drone availability updated successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating drone availability' });
  }



}

const confirmOrder = async (req,res)=>{
   const {id} = req.body
   try {
     const booking = await Booking.findById(id)
     if(!booking){
      return res.json({success:false,message:'Booking not found'})
     }

     booking.orderConfirmed = true
     await booking.save()

     res.json({success:true,message:'Order confirmed successfully'})
   } catch (error) {
     console.log(error)
   }
}

// upadate pilot

const updatePilot = async (req,res) => {
  try {
    const { bookingId } = req.params;
    const { pilot, pilotName } = req.body; // Only taking pilot-related fields

    // Find the booking by ID
    const booking = await Booking.findById(bookingId);
    if (!booking) {
      return res.status(404).json({ message: "Booking not found" });
    }

    // Update only pilot fields
    if (pilot !== undefined) {
      booking.pilot = pilot;
      booking.pilotName = pilotName || booking.pilotName;
      booking.pilotConfirm = false;
      booking.pilotCancelled = false;
    }

    await booking.save();

    res.status(200).json({ message: "Pilot updated successfully", booking });
  } catch (error) {
    console.error("Error updating pilot:", error);
    res.status(500).json({ message: "Internal server error" });
  }
}

// update copilot

const updateCoPilot = async (req,res) => {
  try {
    const { bookingId } = req.params;
    const { coPilot, coPilotName } = req.body; // Only taking pilot-related fields

    // Find the booking by ID
    const booking = await Booking.findById(bookingId);
    if (!booking) {
      return res.status(404).json({ message: "Booking not found" });
    }

    // Update only pilot fields
    if (coPilot !== undefined) {
      booking.copilot = coPilot;
      booking.copilotName = coPilotName || booking.copilotName;
      booking.copilotConfirm = false;
      booking.copilotCancelled = false;
      booking.orderConfirmed = false;
    }

    await booking.save();

    res.status(200).json({ message: "Co pilot updated successfully", booking });
  } catch (error) {
    console.error("Error updating pilot:", error);
    res.status(500).json({ message: "Internal server error" });
  }
}


const addWorkingDays = async (req,res) => {
  try {
    const newEntry = new WorkingDay(req.body);
    await newEntry.save();
    res.status(201).json({success:true,newEntry});
} catch (error) {
    res.status(500).json({ error: "Failed to save data" });
}
}


const getWorkingDays = async (req,res) => {
  try {
    const workingDays = await WorkingDay.find();
    res.json({ success: true, workingDays });
} catch (error) {
    console.error("Error fetching working days:", error);
    res.status(500).json({ success: false, message: "Server error" });
}
}

const deleteWorkingDay = async (req,res) => {
  try {
    const { id } = req.params;
    const deletedItem = await WorkingDay.findByIdAndDelete(id);
    
    if (!deletedItem) {
        return res.status(404).json({ message: "Working day not found" });
    }

    res.json({success:true, message: "Working day deleted successfully" });
} catch (error) {
    console.error("Error deleting working day:", error);
    res.status(500).json({ success:false, message: "Server error" });
}
}

export {getAllDronesWithParts,getFullDroneById,createFullDrone, addDrone, getAllBookings, loginAdmin, adminCancelBooking, removeDrone,changeAvailability,addCrop,removeCrop,confirmOrder ,updatePilot,updateCoPilot, addWorkingDays,getWorkingDays , deleteWorkingDay}