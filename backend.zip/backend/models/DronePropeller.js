export default (sequelize, DataTypes, AuditFields) => {
  const DronePropeller = sequelize.define('DronePropeller', {
    drone_id: DataTypes.INTEGER,
    propeller_id: DataTypes.INTEGER,
    propeller_qty: DataTypes.INTEGER,
    ...AuditFields,
  }, {
    tableName: 'DRONE_PROPELLER',
  });

  return DronePropeller;
};
