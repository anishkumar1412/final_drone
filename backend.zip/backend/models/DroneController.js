const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const AuditFields = require('./auditFields');

const DroneController = sequelize.define('DroneController', {
  drone_id: DataTypes.INTEGER,
  transmitter_id: DataTypes.INTEGER,
  receiver_id: DataTypes.INTEGER,
  ...AuditFields,
}, {
  tableName: 'DRONE_CONTROLLER',
});

module.exports = DroneController;
