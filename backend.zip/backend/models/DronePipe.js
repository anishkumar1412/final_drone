const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const AuditFields = require('./auditFields');

const DronePipe = sequelize.define('DronePipe', {
  drone_id: DataTypes.INTEGER,
  pipe_id: DataTypes.INTEGER,
  pipe_qty: DataTypes.INTEGER,
  ...AuditFields,
}, {
  tableName: 'DRONE_PIPE',
});

module.exports = DronePipe;
