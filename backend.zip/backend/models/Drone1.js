// const AuditFields = require('./auditFields');

export default (sequelize, DataTypes, AuditFields) => {
  const Drone = sequelize.define('Drone', {
    owner_id: DataTypes.INTEGER,
    model: DataTypes.STRING,
    name: DataTypes.STRING,
    range: DataTypes.FLOAT,
    speed: DataTypes.FLOAT,
    weight: DataTypes.FLOAT,
    is_level_sensor: DataTypes.BOOLEAN,
    level_sensor_id: DataTypes.INTEGER,
    is_allen_key: DataTypes.BOOLEAN,
    allen_key_id: DataTypes.INTEGER,
    water_pump_id: DataTypes.INTEGER,
    is_extension_board: DataTypes.BOOLEAN,
    extension_board_id: DataTypes.INTEGER,
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null
    },

    ...AuditFields,
  }, {

    tableName: 'DRONE',
    timestamps: false,
  });

  return Drone;
};
