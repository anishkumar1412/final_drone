const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const AuditFields = require('./auditFields');

const DroneCharger = sequelize.define('DroneCharger', {
  drone_id: DataTypes.INTEGER,
  charger_id: DataTypes.INTEGER,
  is_charger_cable: DataTypes.BOOLEAN,
  ischarger_pcable: DataTypes.BOOLEAN,
  ...AuditFields,
}, {
  tableName: 'DRONE_CHARGER',
});

module.exports = DroneCharger;
