export default (sequelize, DataTypes, AuditFields) => {
  const DroneMotor = sequelize.define('DroneMotor', {
    drone_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    motor_number: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: "Motor 1, Motor 2, etc.",
    },
    motor_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    motor_type: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    motor_speed: {
      type: DataTypes.FLOAT,
      allowNull: true,
    },
    motor_power: {
      type: DataTypes.FLOAT,
      allowNull: true,
    },
    ...AuditFields,
  }, {
    tableName: 'DRONE_MOTOR',
    timestamps: false,
  });

  return DroneMotor;
};
