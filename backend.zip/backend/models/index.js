import { Sequelize, DataTypes, QueryTypes } from "sequelize";
import db from "../config/db.js";


import createUserModel from '../models/User.js';
import DroneModel from './Drone1.js';
import DroneArmsModel from './DroneArms.js';
import DroneBatteryModel from './DroneBattery.js';
import DroneMotorModel from './DroneMotor.js';
import DronePropellerModel from './DronePropeller.js';

// Initialize Sequelize
const sequelize = new Sequelize(
  db.DATABASE,
  db.USER,
  db.PASSWORD,
  {
    host: db.HOST,
    dialect: db.DIALECT,
    logging: false,
    pool: {
      max: 40,
      min: 0,
      acquire: 30000,
      idle: 10000,
    },
  }
);

// Test DB connection
sequelize
  .authenticate()
  .then(() => {
    console.log("✅ Connection has been established successfully.");
  })
  .catch((err) => {
    console.error("❌ Unable to connect to the database:", err);
  });

// Initialize db object
const db1 = {};
db1.Sequelize = Sequelize;
db1.sequelize = sequelize;
db1.DataTypes = DataTypes;
db1.QueryTypes = QueryTypes;

// Register all models
db1.User = createUserModel(sequelize, DataTypes);
db1.Drone1 = DroneModel(sequelize, DataTypes);
db1.DroneArms = DroneArmsModel(sequelize, DataTypes);
db1.DroneBattery = DroneBatteryModel(sequelize, DataTypes);
db1.DroneMotor = DroneMotorModel(sequelize, DataTypes);
db1.DronePropeller = DronePropellerModel(sequelize, DataTypes);

// Sync all models
sequelize.sync({ alter: true })
  .then(() => {
    console.log("✅ All models were synchronized successfully.");
  })
  .catch((err) => {
    console.error("❌ Sync error:", err);
  });

export default db1;
