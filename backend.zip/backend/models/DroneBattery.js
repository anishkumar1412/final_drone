// const AuditFields = require('./auditFields');

export default (sequelize, DataTypes, AuditFields) => {
  const DroneBattery = sequelize.define('DroneBattery', {
    drone_id: DataTypes.INTEGER,
    battery_id: DataTypes.INTEGER,
    battery_qty: DataTypes.INTEGER,
    ...AuditFields,
  }, {
    tableName: 'DRONE_BATTERY',
  });

  return DroneBattery;
};
