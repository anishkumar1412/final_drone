const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const AuditFields = require('./auditFields');

const DroneLandingGear = sequelize.define('DroneLandingGear', {
  drone_id: DataTypes.INTEGER,
  landing_gear_id: DataTypes.INTEGER,
  landing_gear_qty: DataTypes.INTEGER,
  ...AuditFields,
}, {
  tableName: 'DRONE_LANDING_GEAR',
});

module.exports = DroneLandingGear;
