export default (sequelize, DataTypes) => {
  const DroneArms = sequelize.define('DroneArms', {
    drone_id: DataTypes.INTEGER,
    arms_id: DataTypes.INTEGER,
    arms_qty: DataTypes.INTEGER,
    createdAt: DataTypes.DATE,
    updatedAt: DataTypes.DATE,
  }, {
    tableName: 'DRONE_ARMS',
  });

  return DroneArms;
};
