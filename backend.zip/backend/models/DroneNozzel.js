const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const AuditFields = require('./auditFields');

const DroneNozzel = sequelize.define('DroneNozzel', {
  drone_id: DataTypes.INTEGER,
  nozzel_id: DataTypes.INTEGER,
  nozzel_qty: DataTypes.INTEGER,
  ...AuditFields,
}, {
  tableName: 'DRONE_NOZZEL',
});

module.exports = DroneNozzel;
