import mongoose from "mongoose";

const workingDaySchema = new mongoose.Schema({
    startAcre: Number,
    endAcre: Number,
    workingDays: Number,
});


const WorkingDay = mongoose.model("WorkingDat", workingDaySchema);

export default WorkingDay;