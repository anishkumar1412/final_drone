const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const AuditFields = require('./auditFields');

const DroneNutBolt = sequelize.define('DroneNutBolt', {
  drone_id: DataTypes.INTEGER,
  bolt_type_id: DataTypes.INTEGER,
  nut_type_id: DataTypes.INTEGER,
  bolt_qty: DataTypes.INTEGER,
  ...AuditFields,
}, {
  tableName: 'DRONE_NUT_BOLT',
});

module.exports = DroneNutBolt;
